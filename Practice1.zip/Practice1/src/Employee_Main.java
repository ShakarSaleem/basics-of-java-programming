
public class Employee_Main {

	public static void main(java.lang.String[] args) {
		// TODO Auto-generated method stub

		/*
		 * Employee shakar, waseem, wasaq;
		 * 
		 * shakar = new Employee(); 
		 * waseem = new Employee(); 
		 * wasaq = new Employee();
		 */

		Employee shakar = new Employee();
		Employee waseem = new Employee();
		Employee wasaq = new Employee();

		shakar.salary = 98635;
		shakar.bonus = 12356;
		shakar.CalculateTotalPay();
	}

}
