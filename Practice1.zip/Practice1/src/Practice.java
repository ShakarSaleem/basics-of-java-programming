

public class Practice {

	public static void main(java.lang.String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hello world");
		//add
		int x = 10;
		int y = 234;
		int result = x + y;
		System.out.println("sum is :" + result);
	
		

	}

}
