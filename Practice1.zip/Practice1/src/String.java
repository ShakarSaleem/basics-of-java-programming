

public class String {

	public static void main(java.lang.String[] args) {
		// TODO Auto-generated method stub
		java.lang.String x = "shakar saleem";
		System.out.println("hello " + x);

		java.lang.String age = "37";
		java.lang.String salary = "65123.36";
		// wrapper class string to int;
		int a = Integer.parseInt(age) + 9;
		System.out.println(a);
		double b = Double.parseDouble(salary) * 9;
		System.out.println(b);
	}

}
