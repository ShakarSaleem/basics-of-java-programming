

public class For {

	public static void main(java.lang.String[] args) {
		// TODO Auto-generated method stub
		for (int i = 0; i <= 10; i++) {
			System.out.println("i =" + i);
		}

	}

}
