
public class While {

	public static void main(java.lang.String[] args) {
		// TODO Auto-generated method stub
		int x = -34;

		while (x <= 0) {
			System.out.println("x= " + x);
			x *= 2;
			// or x=x+1;
			// or X+=1;
		}
	}

}
