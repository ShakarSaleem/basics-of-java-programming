

public class Do_While {

	public static void main(java.lang.String[] args) {
		// TODO Auto-generated method stub
		int x = 23;
		do {
			System.out.println("x=" + x);
			x--;
		} while (x > 0);
	}

}
